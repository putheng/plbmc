<div class="container">
    <div class="row">
        <div class="col-md-9 col-md-offset-1">
            <?php if(session()->has('success')): ?>
                <div class="alert alert-success" role="alert"> 
                    <strong>Well done!</strong> 
                    <?php echo e(session('success')); ?> 
                </div>
            <?php endif; ?>
            <?php if(session()->has('error')): ?>
                <div class="alert alert-error" role="alert"> 
                    <strong>Well done!</strong> 
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
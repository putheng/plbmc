<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">បន្ថែមការិយាល័យជំនាញ</div>

                <div class="panel-body">
                    <form action="<?php echo e(route('office.create')); ?>" method="post">
                        
                        <div class="form-group<?php echo e($errors->has('group') ? ' has-error' : ''); ?>">
                            <label class="control-label">Grop Name:</label>
                            <select class="form-control" name="group">
                                <?php $__currentLoopData = $group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </select>
                            <?php if($errors->has('group')): ?>
                                <span class="help-block">
                                    <?php echo e($errors->first('group')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error': ''); ?>">
                            <label class="control-label">Name :</label>
                            <input type="text" name="name" class="form-control">
                            <?php if($errors->has('name')): ?>
                                <span class="help-block"><?php echo e($errors->first('name')); ?></span>
                            <?php endif; ?>
                        </div>
                        
                        <br>
                        <?php echo e(csrf_field()); ?>

                        <input type="submit" value="Submit" class="btn btn-primary">
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
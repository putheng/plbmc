<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <?php echo e($office->name); ?> 
                    (<?php echo e($office->officers()->count()); ?>)
                </div>

                <div class="panel-body">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <th>Name:</th>
                            <th>ID</th>
                            <th>Gender</th>
                            <th>Level</th>
                            <th>Position</th>
                            <th>Phone</th>
                            
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $officers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $officer): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <tr>
                                    <td><?php echo e(($key + 1)); ?>

                                        <a href="<?php echo e(route('officer.show', [$officer])); ?>"><?php echo e($officer->name); ?></a></td>
                                    <td><?php echo e($officer->identity); ?></td>
                                    <th><?php echo e($officer->gender == 'male' ? 'ប្រុស' : 'ស្រី'); ?></th>
                                    <td><?php echo e($officer->level->name); ?></td>
                                    <td><?php echo e($officer->position->name); ?></td>
                                    <td><?php echo e($officer->phone); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </tbody>
                    </table>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
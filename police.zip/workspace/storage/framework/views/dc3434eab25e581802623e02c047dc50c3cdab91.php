<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <form action="<?php echo e(route('checking.offices', $office)); ?>" method="post">
                <div class="panel-heading"> 
                    <?php echo e($office->name); ?> 
                    <input type="date" name="dates" class="pull-right">
                    <?php if($errors->has('dates')): ?>
                        <strong class="text-danger pull-right"><?php echo e($errors->first('dates')); ?></strong>
                    <?php endif; ?>
                </div>
                    
                <div class="panel-body">
                    
                    <ul class="list-group">
                        <?php echo e(csrf_field()); ?>

                        <table class="table table-bordered text-center">
                            <thead>
                                <th class="text-center">អត្ថលេខ</th>
                                <th>ឈ្មោះ</th>
                                <th class="text-center">មានមុខ</th>
                                <th class="text-center">ច្បាប់</th>
                                <th class="text-center">ឈឺ</th>
                                <th class="text-center">បេសកកម្ម</th>
                                <th class="text-center">រៀន</th>
                                <th class="text-center">សេរី</th>
                                <th class="text-center">ផ្ទេរ</th>
                                <th class="text-center">មរណៈ</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $office->officers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $officer): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <tr>
                                    <td><?php echo e($officer->identity); ?></td>
                                    <td class="text-left"><?php echo e($officer->name); ?></td>
                                    <?php $__currentLoopData = \App\Models\Status::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                        <td class="radio-toolbar">
                                            <input <?php echo e($key == 0 ? 'checked' : ''); ?> id="<?php echo e($key); ?>_a_<?php echo e($officer->id); ?>" type="radio" value="<?php echo e($item->id); ?>" <?php echo e(old('result.'. $officer->id) == $item->id ? 'checked' : ''); ?> name="result[<?php echo e($officer->id); ?>]">
                                            <label class="btn btn-sm btn-info" for="<?php echo e($key); ?>_a_<?php echo e($officer->id); ?>"><?php echo e($item->name); ?>

                                                
                                            </label>
                                        </td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </tbody>
                        </table>
                    
                    </ul>
                    
                </div>
                <div class="panel-footer">
                    <input type="submit" value="Submit" class="btn btn-primary">
                </div>
                </form>
            </div>
        </div>
    </div>
</div>
<style>
.radio-toolbar input[type="radio"] {display:none;}
.radio-toolbar label {
    font-weight: 100;
}
.radio-toolbar input[type="radio"]:checked+label { 
    background:red !important;
}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
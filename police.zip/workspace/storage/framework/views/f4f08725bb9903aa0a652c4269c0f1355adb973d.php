<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading"> <?php echo e($officer->name); ?> </div>

                <div class="panel-body">
                    
                    <ul class="list-group">
                        <li class="list-group-item">
                            <strong>អត្ថលេខ :</strong>
                            <?php echo e($officer->identity); ?>

                        </li>
                        <li class="list-group-item">
                            <strong>ភេទ :</strong>
                            <?php echo e($officer->gender); ?>

                        </li>
                        <li class="list-group-item">
                            <strong>ឋានន្តរសក្តិ :</strong>
                            <?php echo e($officer->level->name); ?>

                        </li>
                        <li class="list-group-item">
                            <strong>ឋានៈ :</strong>
                            <?php echo e($officer->position->name); ?>

                        </li>
                        <li class="list-group-item">
                            <strong>លេខទូរសព្ទ : :</strong>
                            <?php echo e($officer->phone); ?>

                        </li>
                    </ul>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
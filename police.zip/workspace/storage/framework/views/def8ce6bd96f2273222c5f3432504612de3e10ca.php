<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading"> <?php echo e($office->name); ?> </div>

                <div class="panel-body">
                <form action="<?php echo e(route('officer.create', $office)); ?>" method="post">
                    <div class="form-group<?php echo e($errors->has('name') ? ' has-error': ''); ?>">
                        <label class="control-label">ឈ្មោះ :</label>
                        <input type="text" name="name" class="form-control">
                        <?php if($errors->has('name')): ?>
                            <span class="help-block"><?php echo e($errors->first('name')); ?></span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="form-group<?php echo e($errors->has('gender') ? ' has-error': ''); ?>">
                        <label class="control-label">ភេទ :</label>
                        <select name="gender" class="form-control">
                            <option value="male">ប្រុស</optio>
                            <option value="female">ស្រី</option>  
                        </select>
                        <?php if($errors->has('gender')): ?>
                            <span class="help-block"><?php echo e($errors->first('gender')); ?></span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="form-group<?php echo e($errors->has('identity') ? ' has-error': ''); ?>">
                        <label class="control-label">អត្ថលេខ :</label>
                        <input type="text" name="identity" class="form-control">
                        <?php if($errors->has('identity')): ?>
                            <span class="help-block"><?php echo e($errors->first('identity')); ?></span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="form-group<?php echo e($errors->has('position') ? ' has-error': ''); ?>">
                        <label class="control-label">ឋានៈ </label>
                        <select name="position" class="form-control">
                            <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <option value="<?php echo e($position->id); ?>"><?php echo e($position->name); ?></optio>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </select>
                        <?php if($errors->has('position')): ?>
                            <span class="help-block"><?php echo e($errors->first('position')); ?></span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="form-group<?php echo e($errors->has('level') ? ' has-error': ''); ?>">
                        <label class="control-label">ឋានន្តរសក្តិ </label>
                        <select name="level" class="form-control">
                            <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <option value="<?php echo e($level->id); ?>"><?php echo e($level->name); ?></optio>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </select>
                        <?php if($errors->has('level')): ?>
                            <span class="help-block"><?php echo e($errors->first('level')); ?></span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="form-group<?php echo e($errors->has('phone') ? ' has-error': ''); ?>">
                        <label class="control-label">លេខទូរសព្ទ :</label>
                        <input type="text" name="phone" class="form-control">
                        <?php if($errors->has('phone')): ?>
                            <span class="help-block"><?php echo e($errors->first('phone')); ?></span>
                        <?php endif; ?>
                    </div>
                    
                    <br>
                    <?php echo e(csrf_field()); ?>

                    <input type="submit" value="Submit" class="btn btn-primary">
                </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>